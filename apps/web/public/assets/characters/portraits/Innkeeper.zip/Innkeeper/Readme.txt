Graphics created by JosephSeraph.
Free use! 

Please consider becoming my Patron so I can keep on making cool resources! :))
https://patreon.com/JosehpSeraph

If you decide to use this on a project, I'd love you to tell me about it! 
I love seeing what people create with my graphics! �Lw`)/ <3

I'm JosephSeraph everywhere so there's twitter, RpgMakerNetwork, RpgMakerWeb forums, DeviantArt, SeraphCircle on youtube and a plethora of other places :>

Have a nice day! 